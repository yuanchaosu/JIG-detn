import random
import torch
import numpy as np
import dset_mod

seed = 1
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print("\nSelected device:", device, end="\n\n")

tmod = dset_mod.Train_test(dataset='moni', device=device, skip_train=False, save=True)
tmod.run(smry=False)
